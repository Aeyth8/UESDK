# UEVR SDK

This is NOT the API, the API is [here](https://github.com/praydog/UEVR/tree/master/include/)
