#pragma once

#include "AActor.hpp"

namespace sdk {
class APawn : public AActor {
public:
    static UClass* static_class();

protected:
};
}