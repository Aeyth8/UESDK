#pragma once

namespace sdk {
namespace globals {
float& get_near_clipping_plane(); // GNearClippingPlane
}
}