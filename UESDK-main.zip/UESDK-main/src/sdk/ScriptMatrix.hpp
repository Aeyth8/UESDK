#pragma once

#include "UClass.hpp"

namespace sdk {
class ScriptMatrix : public UObject {
public:
    static UScriptStruct* static_struct();

protected:
};
}