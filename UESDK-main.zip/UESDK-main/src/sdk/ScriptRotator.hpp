#pragma once

#include "UClass.hpp"

namespace sdk {
class ScriptRotator : public UObject {
public:
    static UScriptStruct* static_struct();

protected:
};
}