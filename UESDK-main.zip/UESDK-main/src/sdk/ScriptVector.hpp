#pragma once

#include "UClass.hpp"

namespace sdk {
class ScriptVector : public UObject {
public:
    static UScriptStruct* static_struct();

protected:
};
}