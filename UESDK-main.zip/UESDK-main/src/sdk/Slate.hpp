#pragma once

#include <optional>

namespace sdk {
namespace slate {
std::optional<uintptr_t> locate_draw_window_renderthread_fn();
}
}