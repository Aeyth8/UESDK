#pragma once

#include "UObject.hpp"

namespace sdk {
class UEnum : public UObject {
public:
    static UClass* static_class();

private:
    // TODO
};
}