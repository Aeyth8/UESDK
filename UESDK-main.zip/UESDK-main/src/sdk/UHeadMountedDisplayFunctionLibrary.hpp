#pragma once

#include "UClass.hpp"
#include "UObject.hpp"

namespace sdk {
class UHeadMountedDisplayFunctionLibrary : public sdk::UObject {
public:
    static UClass* static_class();

private:
};
}