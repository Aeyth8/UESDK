#pragma once

namespace sdk {
class FUObjectHashTables {
public:
    static FUObjectHashTables* get();
};
}