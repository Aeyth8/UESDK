#pragma once

#include "UObject.hpp"

namespace sdk {
class UWorld : public UObject {
public:

private:
};
}