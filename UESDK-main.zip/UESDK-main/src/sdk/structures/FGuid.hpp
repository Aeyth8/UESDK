// Generated with sdkgenny
#pragma once

#include <cstdint>

namespace ue{
#pragma pack(push, 1)
struct FGuid {
    int32_t A; // 0x0
    int32_t B; // 0x4
    int32_t C; // 0x8
    int32_t D; // 0xc
}; // Size: 0x10
#pragma pack(pop)
}